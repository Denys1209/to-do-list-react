import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyD5QgYhlAoojT100fjBjLl40yBoqJH7Tw4",
  authDomain: "todolist-cd732.firebaseapp.com",
  projectId: "todolist-cd732",
  storageBucket: "todolist-cd732.appspot.com",
  messagingSenderId: "573761012144",
  appId: "1:573761012144:web:de65b253aa053d8c6a1675"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);